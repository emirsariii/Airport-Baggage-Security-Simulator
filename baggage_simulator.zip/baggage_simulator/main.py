import pygame
from gui import baslat_gui

if __name__ == "__main__":
    baslat_gui()
