yasakli_esyalar = ["bıçak", "çakı", "silah", "patlayıcı", "el bombası"]

def esya_tehlikeli_mi(esya):
    return esya.lower() in yasakli_esyalar